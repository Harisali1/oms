<?php

namespace App\Http\Controllers\Api;


class AuthApiController extends ApiBaseController
{

}
