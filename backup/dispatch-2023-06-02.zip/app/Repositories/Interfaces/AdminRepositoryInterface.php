<?php

namespace App\Repositories\Interfaces;

/**
 * Interface AdminRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface AdminRepositoryInterface extends RepositoryInterface
{

}
