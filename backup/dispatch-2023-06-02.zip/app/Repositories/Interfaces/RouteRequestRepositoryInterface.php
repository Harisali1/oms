<?php

namespace App\Repositories\Interfaces;

/**
 * Interface RouteRequestRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface RouteRequestRepositoryInterface extends RepositoryInterface
{

}
