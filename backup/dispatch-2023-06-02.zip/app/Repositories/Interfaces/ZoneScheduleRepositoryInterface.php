<?php

namespace App\Repositories\Interfaces;

/**
 * Interface ZoneScheduleRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface ZoneScheduleRepositoryInterface extends RepositoryInterface
{

}
