<?php

namespace App\Repositories\Interfaces;

/**
 * Interface OrderCategoryRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface OrderCategoryRepositoryInterface extends RepositoryInterface
{

}
