<?php

namespace App\Repositories\Interfaces;

/**
 * Interface SiteSettingRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface SiteSettingRepositoryInterface extends RepositoryInterface
{

}
