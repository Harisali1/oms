<?php

namespace App\Repositories\Interfaces;

/**
 * Interface UserRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface QuizRepositoryInterface extends RepositoryInterface
{

}
