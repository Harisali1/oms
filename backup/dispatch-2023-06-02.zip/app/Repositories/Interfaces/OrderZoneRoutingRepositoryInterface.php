<?php

namespace App\Repositories\Interfaces;

/**
 * Interface OrderZoneRoutingRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface OrderZoneRoutingRepositoryInterface extends RepositoryInterface
{

}
