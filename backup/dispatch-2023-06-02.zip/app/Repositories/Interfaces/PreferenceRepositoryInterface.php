<?php

namespace App\Repositories\Interfaces;

/**
 * Interface RouteRequestRepositoryInterface
 *
 * @author Muhammad Zahid
 * email : zahidnasim@live.com
 */
interface PreferenceRepositoryInterface
{

}
