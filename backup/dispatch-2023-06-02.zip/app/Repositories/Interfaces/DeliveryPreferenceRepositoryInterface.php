<?php

namespace App\Repositories\Interfaces;

/**
 * Interface DeliveryPreferenceRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface DeliveryPreferenceRepositoryInterface extends RepositoryInterface
{

}
