<?php

namespace App\Repositories\Interfaces;

/**
 * Interface JoeyZoneScheduleRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface JoeyZoneScheduleRepositoryInterface extends RepositoryInterface
{

}
