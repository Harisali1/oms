<?php

namespace App\Repositories\Interfaces;

/**
 * Interface DeliveryTypeRepositoryInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface DeliveryTypeRepositoryInterface extends RepositoryInterface
{

}
