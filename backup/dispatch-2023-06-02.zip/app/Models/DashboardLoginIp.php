<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DashboardLoginIp extends Model
{

    protected $table = 'dashboard_login_ips';


    protected $guarded = [];



}
