<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class ReturnOrder extends Model
{

    public $table = 'return_order';

    protected $guarded = [];



}
