<?php

namespace App\Models\Interfaces;

/**
 * Interface SiteSettingInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface SiteSettingInterface
{

}
