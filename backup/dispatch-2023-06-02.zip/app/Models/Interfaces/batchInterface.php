<?php

namespace App\Models\Interfaces;

/**
 * Interface UserInterface
 *
 * @author Abdul Basit <abdul.basit@joeyco.com>
 */
interface batchInterface
{

}
