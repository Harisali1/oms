<?php
/**
 * Created by PhpStorm.
 * User: Joeyco-0031PK
 * Date: 11/17/2021
 * Time: 8:18 PM
 */

namespace App\Models\Interfaces;


interface JoeyRoutificJobRouteInterface
{

}