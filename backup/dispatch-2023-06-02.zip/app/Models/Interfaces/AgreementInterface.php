<?php

namespace App\Models\Interfaces;

/**
 * Interface UserInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface AgreementInterface
{

}
