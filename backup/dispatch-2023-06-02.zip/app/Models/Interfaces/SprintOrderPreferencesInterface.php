<?php

namespace App\Models\Interfaces;

/**
 * Interface UserInterface
 *
 *
 */
interface SprintOrderPreferencesInterface
{

}
