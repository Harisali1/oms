<?php

namespace App\Models\Interfaces;

/**
 * Interface SprintZoneScheduleInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface SprintZoneScheduleInterface
{

}
