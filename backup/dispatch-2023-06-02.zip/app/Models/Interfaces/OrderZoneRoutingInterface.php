<?php

namespace App\Models\Interfaces;

/**
 * Interface OrderZoneRoutingInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface OrderZoneRoutingInterface
{

}
