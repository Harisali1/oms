<?php

namespace App\Models\Interfaces;

/**
 * Interface JobSlotInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface JobSlotInterface
{

}
