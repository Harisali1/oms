<?php

namespace App\Models\Interfaces;

/**
 * Interface DeliveryPreferenceInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface DeliveryPreferenceInterface
{

}
