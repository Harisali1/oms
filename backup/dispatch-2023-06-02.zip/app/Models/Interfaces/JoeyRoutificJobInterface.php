<?php
/**
 * Created by PhpStorm.
 * User: Joeyco-0031PK
 * Date: 11/16/2021
 * Time: 9:13 PM
 */

namespace App\Models\Interfaces;


interface JoeyRoutificJobInterface
{

}