<?php

namespace App\Models\Interfaces;

/**
 * Interface ScheduleInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface ZoneScheduleInterface
{

}
