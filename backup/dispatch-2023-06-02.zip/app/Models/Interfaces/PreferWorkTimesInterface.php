<?php

namespace App\Models\Interfaces;

/**
 * Interface SiteSettingInterface
 *
 * @author Muhammad Adnan <adnanandeem1994@gmail.com>
 * @date   30/09/2020
 */
interface  PreferWorkTimesInterface
{

}
