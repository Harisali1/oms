<?php

namespace App\Models\Interfaces;

/**
 * Interface SprintZoneInterface
 *
 *
 */
interface SprintZoneInterface
{

}
