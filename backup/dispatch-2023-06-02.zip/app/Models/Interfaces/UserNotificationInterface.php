<?php
/**
 * Created by PhpStorm.
 * User: Joeyco-0031PK
 * Date: 11/16/2021
 * Time: 6:48 PM
 */

namespace App\Models\Interfaces;


interface UserNotificationInterface
{

}