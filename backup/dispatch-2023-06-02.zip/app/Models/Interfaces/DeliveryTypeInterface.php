<?php

namespace App\Models\Interfaces;

/**
 * Interface DeliveryTypeInterface
 *
 * @author Yousuf Sadiq <muhammad.sadiq@joeyco.com>
 */
interface DeliveryTypeInterface
{

}
