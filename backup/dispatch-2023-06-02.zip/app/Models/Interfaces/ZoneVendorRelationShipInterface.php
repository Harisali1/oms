<?php

namespace App\Models\Interfaces;

/**
 * Interface ZoneVendorRelationShipInterface
 *
 * 
 */
interface ZoneVendorRelationShipInterface
{

}
