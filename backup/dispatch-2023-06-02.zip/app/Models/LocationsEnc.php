<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LocationsEnc extends Model
{
    public $table = 'locations_enc';
    protected $guarded = [];
}
