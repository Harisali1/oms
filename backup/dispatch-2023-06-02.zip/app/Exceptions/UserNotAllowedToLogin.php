<?php

namespace App\Exceptions;

class UserNotAllowedToLogin extends BaseException {}
