<p><b>Dear {{ $data['name'] }},</b></p>

<p>Thank you for contacting with us, we have received your query our representative will contact with you soon</p>

<p>Thanks,</p>
<p>
    <b>Best Regards,</b>
    <br />
    {{ $siteSettings->site_title }}
</p>
