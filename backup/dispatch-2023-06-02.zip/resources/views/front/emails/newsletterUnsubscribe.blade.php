<p><b>Dear Sir/Madam,</b></p>

<p>We have received query for unsubscribe newsletter, please click <a href="{!! $data['link'] !!}">here</a> or link given bellow to unsubscribe</p>
<p><a href="{!! $data['link'] !!}">{!! $data['link'] !!}</a></p>

<p>Thanks,</p>

<p>
    <b>Best Regards,</b>
    <br />
    {{ $siteSettings->site_title }}
</p>
