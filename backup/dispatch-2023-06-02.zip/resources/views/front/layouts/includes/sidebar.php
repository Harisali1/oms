<!-- Sidebar -->
<aside id="left_sidebar" class="col-12 col-lg-3">
    <div class="inner">
        <div class="widget_sidebar d-none d-lg-block">
            <nav class="sidebar_nav">
                <ul class="no-list">
                    <li><a href="account.php">Profile</a></li>
                    <li><a href="referrals.php">Referrals</a></li>
                    <li><a href="payments.php">Payments</a></li>
                    <li><a href="documents.php">Documents</a></li>
                </ul>
            </nav>
        </div>
    </div>
</aside>