<ul class="no-list d-flex flex-wrap dispatch_actions">
    <li><a data-toggle="modal" data-target="#transferJoeySprint" href="#" class="btn btn-basecolor1 btn-mb" title="Transfer Joey Sprint">T</a></li>
    <li><a href="edit-custom-run.php" class="btn btn-basecolor1 btn-mb" title="Edit Custom run">E</a></li>
    <li><a data-toggle="modal" data-target="#orderBroadcast" href="#" class="btn btn-basecolor1 btn-mb" title="Order broadcast">R</a></li>
    <li><a data-toggle="modal" data-target="#detail" href="#" class="btn btn-basecolor1 btn-mb" title="Detail">D</a></li>
    <li><a data-toggle="modal" data-target="#map" href="#" class="btn btn-basecolor1 btn-mb" title="Map">M</a></li>
    <li><a data-toggle="modal" data-target="#cancel" href="#" class="btn btn-danger btn-mb" title="Cancel">C</a></li>
    <li><a data-toggle="modal" data-target="#flag" href="#" class="btn btn-basecolor1 btn-mb" title="Flag">F</a></li>
    <li><a data-toggle="modal" data-target="#exclusive" href="#" class="btn btn-basecolor1 btn-mb" title="">P</a></li>
    <li><a data-toggle="modal" data-target="#notes" href="#" class="btn btn-basecolor1 btn-mb" title="Notes">N</a></li>
    <li><a href="order-notes.php" class="btn btn-basecolor1 btn-mb" title="Order Notes">ON</a></li>
    <li><a data-toggle="modal" data-target="#assignCode" href="#" class="btn btn-basecolor1 btn-mb" title="Assign Code">AC</a></li>
</ul>