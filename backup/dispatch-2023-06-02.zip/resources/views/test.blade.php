<html>
<head>
    <title>Laravel Google Maps Example</title>
    {!! $map['js'] !!}
</head>
<body>
<div class="container">
    {!! $map['html'] !!}
</div>
</body>
</html>